import Features from '../Features'

export default function FeaturesExample() {
  return <Features />
}

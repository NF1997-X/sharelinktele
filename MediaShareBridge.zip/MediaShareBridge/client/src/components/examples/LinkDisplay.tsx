import LinkDisplay from '../LinkDisplay'

export default function LinkDisplayExample() {
  return (
    <LinkDisplay shareLink="https://t.me/share/abc123xyz456" />
  )
}
